/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.inject.Named;
import javax.enterprise.context.RequestScoped;


@RequestScoped
@Named
public class NewBook {
private String bookid;
     private String bookname;
     private String authorname;
     private String publisher;
     private String category;

     public String action()
     {
        NewBook nb=new NewBook(this.bookid,this.bookname,this.authorname,this.publisher,this.category);
    String insertBook = BookHelper.insertBook(nb);
         return insertBook;
     }
    public NewBook() {
    }

	
    public NewBook(String bookid) {
        this.bookid = bookid;
    }
    public NewBook(String bookid, String bookname, String authorname, String publisher, String category) {
       this.bookid = bookid;
       this.bookname = bookname;
       this.authorname = authorname;
       this.publisher = publisher;
       this.category = category;
    }
   
    public String getBookid() {
        return this.bookid;
    }
    
    public void setBookid(String bookid) {
        this.bookid = bookid;
    }
    public String getBookname() {
        return this.bookname;
    }
    
    public void setBookname(String bookname) {
        this.bookname = bookname;
    }
    public String getAuthorname() {
        return this.authorname;
    }
    
    public void setAuthorname(String authorname) {
        this.authorname = authorname;
    }
    public String getPublisher() {
        return this.publisher;
    }
    
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
    public String getCategory() {
        return this.category;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    
}
