/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Date;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;


@RequestScoped
@Named
public class IssueBook {
private String studentid;
     private String studentname;
     private String bookname;
     private String bookid;
     private Date issuedate;
     private Date returndate;

    public IssueBook() {
    }
public String action()
     {
        IssueBook ib=new IssueBook();
    String insertBook = IssueHelper.issueBook(ib);
         return insertBook;
     }
	
    public IssueBook(String studentid) {
        this.studentid = studentid;
    }
    public IssueBook(String studentid, String studentname, String bookname, String bookid, Date issuedate, Date returndate) {
       this.studentid = studentid;
       this.studentname = studentname;
       this.bookname = bookname;
       this.bookid = bookid;
       this.issuedate = issuedate;
       this.returndate = returndate;
    }
   
    public String getStudentid() {
        return this.studentid;
    }
    
    public void setStudentid(String studentid) {
        this.studentid = studentid;
    }
    public String getStudentname() {
        return this.studentname;
    }
    
    public void setStudentname(String studentname) {
        this.studentname = studentname;
    }
    public String getBookname() {
        return this.bookname;
    }
    
    public void setBookname(String bookname) {
        this.bookname = bookname;
    }
    public String getBookid() {
        return this.bookid;
    }
    
    public void setBookid(String bookid) {
        this.bookid = bookid;
    }
    public Date getIssuedate() {
        return this.issuedate;
    }
    
    public void setIssuedate(Date issuedate) {
        this.issuedate = issuedate;
    }
    public Date getReturndate() {
        return this.returndate;
    }
    
    public void setReturndate(Date returndate) {
        this.returndate = returndate;
    }
    
}
