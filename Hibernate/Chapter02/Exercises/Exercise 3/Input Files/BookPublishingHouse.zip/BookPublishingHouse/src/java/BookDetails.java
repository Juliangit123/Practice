/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.Serializable;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.*;

@RequestScoped
@Named
@Entity
@Table(name="BOOK")
public class BookDetails implements Serializable {
@Id @GeneratedValue
@Column(name="BOOKID")
private String bookID;
@Column(name="BOOKNAME")
private String bookName;
@Column(name="AUTHORNAME")
private String author;
@Column(name="EDITION")
private String edition;
@Column(name="PUBLISHER")
private String publisher;
@Column(name="PUBLISHINGYEAR")
private String pubYear;
@Column(name="CATEGORY")
private String category;
@Column(name="PRICE")
private String price;
@Column(name="QUANTITY")
private String qty;


    public String getBookID() {
        return bookID;
    }

    public void setBookID(String bookID) {
        this.bookID = bookID;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getEdition() {
        return edition;
    }

    public void setEdition(String edition) {
        this.edition = edition;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getPubYear() {
        return pubYear;
    }

    public void setPubYear(String pubYear) {
        this.pubYear = pubYear;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }
    /**
     * Creates a new instance of BookDetails
     */
    public BookDetails() {
    }
}
